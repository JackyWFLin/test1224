
# coding: utf-8

# In[2]:


import os
import sys
import numpy as np
import csv
import pandas as pd
from tqdm import tqdm
from pandas import Series, DataFrame


# In[19]:


l = pd.read_csv('C:/Users/user/Desktop/All_image/data_fold.csv')
num = l['num']
fold = l['fold']
train_num = l['train']
valid_num = l['valid']
test_num = l['test']
train_head1 = []
train_head2 = []
valid_head = []
test_head = []
train1 = []
train2 = []
valid = []
test = []


# In[26]:


a = []
b = []
for i in range(133):
    rd = np.arange(num[i])
    np.random.shuffle(rd)
    #print(rd)
    for j in range(num[i]):
        a='/'+str(fold[i])+'/head/'+str(rd[j])+'.jpg,'+str(fold[i]-1)
        b='/'+str(fold[i])+'/Originals/'+str(rd[j])+'.jpg,'+str(fold[i]-1)
        if j<train_num[i]/2:
            train_head1.append(a)
            train1.append(b)
        elif j<train_num[i]:
            train_head2.append(a)
            train2.append(b)
        elif j<train_num[i]+valid_num[i]:
            valid_head.append(a)
            valid.append(b)
        else:
            test_head.append(a)
            test.append(b)


# In[27]:


print(len(train1))
print(len(train2))
print(len(valid))
print(len(test))


# In[32]:


f = open('train_head1.csv','a')
f.truncate()
f.write('image,labels\n')
for i in train_head1:
    f.write(str(i)+str('\n'))
f.close()

f = open('train1.csv','a')
f.truncate()
f.write('image,labels\n')
for i in train1:
    f.write(str(i)+str('\n'))
f.close()

f = open('train_head2.csv','a')
f.truncate()
f.write('image,labels\n')
for i in train_head2:
    f.write(str(i)+str('\n'))
f.close()

f = open('train2.csv','a')
f.truncate()
f.write('image,labels\n')
for i in train2:
    f.write(str(i)+str('\n'))
f.close()

f = open('valid_head.csv','a')
f.truncate()
f.write('image,labels\n')
for i in valid_head:
    f.write(str(i)+str('\n'))
f.close()

f = open('valid.csv','a')
f.truncate()
f.write('image,labels\n')
for i in valid:
    f.write(str(i)+str('\n'))
f.close()

f = open('test_head.csv','a')
f.truncate()
f.write('image,labels\n')
for i in test_head:
    f.write(str(i)+str('\n'))
f.close()

f = open('test.csv','a')
f.truncate()
f.write('image,labels\n')
for i in test:
    f.write(str(i)+str('\n'))
f.close()


