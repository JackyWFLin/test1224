
# coding: utf-8

# In[2]:


import os
import sys
import numpy as np
import csv
import pandas as pd
from tqdm import tqdm
from pandas import Series, DataFrame

path2 = 'C:/Users/user/Desktop/All_image/data/3/'
print(path2)
A = 'train2.csv'
T = 'train_head2.csv'
print(A)
print(T)

D1 = pd.read_csv(path2+A)
im1 = D1['image']
l1 = D1['labels']

D2 = pd.read_csv(path2+T)
im2 = D2['image']
l2 = D2['labels']

rd = np.arange(len(im1))
np.random.shuffle(rd)
rd1 = rd[0:int(len(im1)/2)]
rd2 = rd[int(len(im1)/2)::]


f1 = open('d1_'+A,'a')
f2 = open('d1_'+T,'a')
f1.truncate()
f2.truncate()
f1.write('image,labels\n')
f2.write('image,labels\n')

for i in rd1:
    f1.write(str(im1[i])+','+str(l1[i])+str('\n'))
    f2.write(str(im2[i])+','+str(l2[i])+str('\n'))
f1.close()
f2.close()

f1 = open('d2_'+A,'a')
f2 = open('d2_'+T,'a')
f1.truncate()
f2.truncate()
f1.write('image,labels\n')
f2.write('image,labels\n')

for i in rd2:
    f1.write(str(im1[i])+','+str(l1[i])+str('\n'))
    f2.write(str(im2[i])+','+str(l2[i])+str('\n'))
f1.close()
f2.close()

