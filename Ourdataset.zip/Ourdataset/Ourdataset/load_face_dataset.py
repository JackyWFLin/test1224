
# coding: utf-8

# In[1]:


import os
import sys
import numpy as np
import cv2
import csv
import pandas as pd
from tqdm import tqdm
from pandas import Series, DataFrame
from keras.preprocessing import image
from pandas import Series, DataFrame




def path_to_tensor(path_name,i):
    # loads RGB image as PIL.Image.Image type
    img_path = path_name+i;
    img = image.load_img(img_path, target_size=(224, 224))
    # convert PIL.Image.Image type to 3D tensor with shape (224, 224, 3)
    aa = image.img_to_array(img)
    # convert 3D tensor to 4D tensor with shape (1, 224, 224, 3) and return 4D tensor
    return np.expand_dims(aa, axis=0)


def read_path(path_name,x):
    list_of_tensors = [path_to_tensor(path_name,i) for i in tqdm(x)]
    return np.vstack(list_of_tensors)


# In[2]:


def load_dataset(path1,path2,n):

    train_images = []
    train_labels = []
    valid_images = []
    valid_labels = []
    test_images = []
    test_labels = []
    if n==0:
        D1 = pd.read_csv(path2+'train.csv')
    D2 = pd.read_csv(path2+'valid.csv')
    D3 = pd.read_csv(path2+'test.csv')
    im1 = D1['image']
    l1 = D1['labels']
    im2 = D2['image']
    l2 = D2['labels']
    im3 = D3['image']
    l3 = D3['labels']
    
    im1 = np.array(im1)
    im2 = np.array(im2)
    im3 = np.array(im3)
    
    l1 = np.array(l1)
    l2 = np.array(l2)
    l3 = np.array(l3)
    
    
    
    train_images = read_path(path1,im1)
    valid_images = read_path(path1,im2)
    test_images = read_path(path1,im3)
    
    train_images = np.array(train_images)
    valid_images = np.array(valid_images)
    test_images = np.array(test_images)
    
    train_labels = l1
    valid_labels = l2
    test_labels = l3
    
    

    print("image shape: ")
    print(train_images.shape)

    
    return train_images,train_labels,valid_images,valid_labels,test_images,test_labels

