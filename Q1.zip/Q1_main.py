#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score,StratifiedKFold,learning_curve,train_test_split

pd.set_option('display.max_columns',None)


# In[2]:


train_path = './Q1/train.csv'
test_path = './Q1/test.csv'
df_train = pd.read_csv(train_path)
df_test = pd.read_csv(test_path)
df_data = df_train.append(df_test)


# In[3]:


one_hot_cols = ["appearedTimeOfDay","city","weather","weatherIcon","continent"]
for c in one_hot_cols:
    df_data = pd.concat([df_data,pd.get_dummies(df_data[c])],axis=1)
df_data = df_data.replace(True,1)
df_data = df_data.replace(False,0)


# In[4]:


df_data = df_data[[i for i in df_train.columns if i not in one_hot_cols]]


# In[5]:


df_train = df_data[:len(df_train)]
df_test = df_data[len(df_train):]


# In[6]:


X = df_train.drop(labels = ['ID','class'] , axis = 1)
Y = df_train['class']


# In[7]:


model = RandomForestClassifier(random_state = 2,n_estimators=250,min_samples_split=20,oob_score = True)
model.fit(X,Y)
print('Bass oob Score : %.3f' % (model.oob_score_))


# In[8]:


X_test = df_test.drop(labels = ['ID','class'] , axis = 1)
Y_test = model.predict(X_test)


# In[9]:


submit = pd.DataFrame({"ID":df_test['ID'],"class":Y_test.astype(int)})


# In[11]:


print(submit)
submit.to_csv('q1_submit.csv',index = False)


# In[ ]:




